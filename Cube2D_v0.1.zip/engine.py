import pygame
import sys
import os
import traceback
from datetime import datetime

class Engine:
    def __init__(self, settings_file='settings.txt'):
        # Чтение настроек из файла
        self.settings = self.load_settings(settings_file)

        # Применяем настройки
        self.width = self.settings['SCREEN_WIDTH']
        self.height = self.settings['SCREEN_HEIGHT']
        self.title = self.settings['WINDOW_TITLE']
        self.max_fps = self.settings['MAX_FPS']
        self.enable_logging = self.settings['ENABLE_LOGGING']
        self.log_file = self.settings['LOG_FILE']

        # Проверка и создание нужных директорий
        self.check_create_directories()

        pygame.init()
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption(self.title)
        self.clock = pygame.time.Clock()
        self.running = self.settings['GAME_LOOP_RUNNING']
        self.objects = pygame.sprite.Group()
        self.current_scene = None

        # Логирование, если включено
        if self.enable_logging:
            self.log_message("Движок запущен.")

    def load_settings(self, settings_file):
        """Чтение настроек из файла"""
        settings = {}

        try:
            with open(settings_file, 'r') as file:
                for line in file:
                    line = line.strip()

                    # Пропускаем комментарии
                    if line.startswith('#') or not line:
                        continue
                    
                    key, value = line.split('=')
                    key = key.strip()
                    value = value.strip()

                    # Преобразуем строки в нужные типы
                    if value.lower() in ['true', 'false']:
                        settings[key] = value.lower() == 'true'
                    elif value.isdigit():
                        settings[key] = int(value)
                    else:
                        settings[key] = value

        except FileNotFoundError:
            print(f"Ошибка: файл настроек {settings_file} не найден.")
            sys.exit()

        return settings

    def check_create_directories(self):
        """Проверяет наличие необходимых папок и создает их при необходимости"""
        directories = ["assets", "assets/images", "assets/sounds", "logs"]
        for dir in directories:
            if not os.path.exists(dir):
                print(f"Создаем директорию: {dir}")
                os.makedirs(dir)

        # Создадим лог-файл, если его нет
        if not os.path.exists(self.log_file):
            with open(self.log_file, "w") as log_file:
                log_file.write("Лог игры Cube2D\n")

    def log_message(self, message):
        """Записываем сообщение в лог-файл"""
        with open(self.log_file, "a") as log_file:
            log_file.write(message + "\n")

    def log_crash(self, error_message):
        """Записываем информацию о краше в файл crash.txt"""
        crash_file_path = "logs/crash.txt"
        with open(crash_file_path, "a") as crash_file:
            crash_file.write(f"\n[{datetime.now()}] - Краш игры\n")
            crash_file.write(f"Ошибка: {error_message}\n")
            crash_file.write("Трассировка стека:\n")
            traceback.print_exc(file=crash_file)
            crash_file.write("\n" + "="*50 + "\n")

    def set_scene(self, scene):
        self.current_scene = scene

    def game_loop(self):
        try:
            print(f"Запуск игрового цикла с максимальным FPS: {self.max_fps}")
            while self.running:
                self.handle_events()
                if self.current_scene:
                    self.current_scene.update()
                    self.current_scene.render(self.screen)
                self.objects.update()  # Обновление всех объектов
                self.objects.draw(self.screen)  # Отображение всех объектов
                pygame.display.flip()  # Обновление экрана
                self.clock.tick(self.max_fps)  # Ограничиваем FPS
            print("Игровой цикл завершен.")
        except Exception as e:
            self.log_crash(str(e))  # Логируем краш
            self.quit()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False

    def quit(self):
        pygame.quit()
        sys.exit()
